

class Resource:
    """
    나중을 위한 Resource
    """
    pass