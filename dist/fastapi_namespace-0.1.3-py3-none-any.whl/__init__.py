from .namespace import Namespace
from .resource import Resource